/**
 * MEBI ACCESSORIES — store API (Netlify Function + Netlify Blobs)
 *
 *   GET  /api/products      public   the live catalogue ({ products: [...] | null })
 *   PUT  /api/products      admin    replace the catalogue
 *   POST /api/upload        admin    save one photo, returns its /api/image/… url
 *   GET  /api/image/<id>    public   serve an uploaded photo
 *   POST /api/login         —        { password } -> { token } (12 hours)
 *
 * The admin password is set in Netlify as the ADMIN_PASSWORD env variable.
 */
import { getStore } from "@netlify/blobs";
import { createHmac, randomUUID, timingSafeEqual } from "node:crypto";

export const config = { path: "/api/*" };

const CATEGORIES = ["Jewellery", "Watches", "Smart Gadgets", "Home & Living"];
const BADGES = ["NEW", "POPULAR", "LIMITED", "SOLD OUT"];
const SAFE_IMAGE = /^(\/api\/image\/[\w-]+|images\/[\w\/. %~-]+)$/;

const password = () => process.env.ADMIN_PASSWORD || "";
const sign = exp => createHmac("sha256", password()).update(String(exp)).digest("hex");
const same = (a, b) => {
  const x = Buffer.from(String(a)), y = Buffer.from(String(b));
  return x.length === y.length && timingSafeEqual(x, y);
};
const isAdmin = req => {
  const [exp, sig] = (req.headers.get("authorization") || "").replace(/^Bearer /, "").split(".");
  return !!password() && Number(exp) > Date.now() && !!sig && same(sig, sign(exp));
};
const json = (data, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json", "cache-control": "no-store" }
  });
const clean = (v, max) => String(v ?? "").replace(/[<>]/g, "").trim().slice(0, max);

function cleanProduct(p) {
  const sizes = (Array.isArray(p.sizes) ? p.sizes : []).map(s => clean(s, 12)).filter(Boolean).slice(0, 10);
  return {
    id: Number(p.id),
    name: clean(p.name, 80),
    price: Math.max(0, Math.round(Number(p.price) || 0)),
    category: CATEGORIES.includes(p.category) ? p.category : CATEGORIES[0],
    images: (Array.isArray(p.images) ? p.images : []).filter(u => SAFE_IMAGE.test(u)).slice(0, 6),
    sizes: sizes.length ? sizes : ["One Size"],
    rating: Math.min(5, Math.max(0, Number(p.rating) || 0)),
    orders: Math.max(0, Math.floor(Number(p.orders) || 0)),
    condition: clean(p.condition, 30),
    badge: BADGES.includes(p.badge) ? p.badge : null,
    dateAdded: /^\d{4}-\d{2}-\d{2}$/.test(p.dateAdded) ? p.dateAdded : new Date().toISOString().slice(0, 10),
    description: clean(p.description, 600)
  };
}

export default async (req) => {
  const route = new URL(req.url).pathname.replace(/^\/api\/?/, "");
  const data = getStore({ name: "mebi", consistency: "strong" });
  const photos = getStore({ name: "mebi-images", consistency: "strong" });

  if (route === "login" && req.method === "POST") {
    if (!password()) return json({ error: "ADMIN_PASSWORD is not set in Netlify yet." }, 500);
    const body = await req.json().catch(() => ({}));
    if (!same(body.password ?? "", password())) {
      await new Promise(r => setTimeout(r, 800)); // slow down guessing
      return json({ error: "Wrong password" }, 401);
    }
    const exp = Date.now() + 12 * 3600 * 1000;
    return json({ token: `${exp}.${sign(exp)}` });
  }

  if (route === "products" && req.method === "GET") {
    return json({ products: await data.get("products", { type: "json" }) });
  }

  if (route === "products" && req.method === "PUT") {
    if (!isAdmin(req)) return json({ error: "Please log in again." }, 401);
    const body = await req.json().catch(() => null);
    if (!body || !Array.isArray(body.products) || body.products.length > 500) {
      return json({ error: "Invalid product list" }, 400);
    }
    const list = body.products.map(cleanProduct).filter(p => p.id && p.name && p.images.length);
    // delete photos that no product uses any more
    const previous = (await data.get("products", { type: "json" })) || [];
    const keep = new Set(list.flatMap(p => p.images));
    for (const url of previous.flatMap(p => p.images)) {
      if (url.startsWith("/api/image/") && !keep.has(url)) await photos.delete(url.split("/").pop());
    }
    await data.setJSON("products", list);
    return json({ ok: true, products: list });
  }

  if (route === "upload" && req.method === "POST") {
    if (!isAdmin(req)) return json({ error: "Please log in again." }, 401);
    const body = await req.json().catch(() => ({}));
    const m = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(body.dataUrl || "");
    if (!m) return json({ error: "Please upload a JPG, PNG or WebP photo." }, 400);
    const buf = Buffer.from(m[2], "base64");
    if (buf.length > 4_000_000) return json({ error: "That photo is too large." }, 413);
    const id = randomUUID();
    await photos.set(id, buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength), {
      metadata: { type: m[1] }
    });
    return json({ url: `/api/image/${id}` });
  }

  if (route.startsWith("image/") && req.method === "GET") {
    const key = route.slice(6);
    const found = /^[\w-]+$/.test(key) ? await photos.getWithMetadata(key, { type: "arrayBuffer" }) : null;
    if (!found) return new Response("Not found", { status: 404 });
    return new Response(found.data, {
      headers: {
        "content-type": found.metadata?.type || "image/jpeg",
        "cache-control": "public, max-age=31536000, immutable"
      }
    });
  }

  return json({ error: "Not found" }, 404);
};
